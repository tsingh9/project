import { connectionObj } from "../config/dbConfig.js";

export function AddPropertyController(request,response){
   try{ const data=request.body;
    const insertQuery=`insert into property values('${data.ptype}','${data.rtype}','${data.pcondition}',${data.availR},${data.totalBed},${data.totalBath},${data.rent},${data.area},${data.ucost},${data.minMonth},${data.mates},'${data.genderPref}','${data.occupation}','${data.amenity}','${data.identity}','${data.city}','${data.address}','${data.landmark}','${data.title}','${data.description}',${data.imgp})`;
    connectionObj.query(insertQuery,(error)=>{
      if(error){
        response.send("error inserting");
      }

      else{
        response.send("successfully inserted");
      }

    });
   }
   catch(error){
    response.send("error inserting");
   }

}

export function DisplayPropertyController(request,response){
  try{  const data=request.body;
    const insertQuery=`se;ect * from property`;
    connectionObj.query(insertQuery,(error)=>{
      if(error){
        response.send("error displaying");
      }

      else{
        response.send("successfully inserted");
      }

    });
  }
  catch(error){
    response.send("Error displaying");
  }

}

export function DeletePropertyController(request,response){
  try{  const data=request.body;
    const insertQuery=`delete from property where id=${data.id}`;
    connectionObj.query(insertQuery,(error)=>{
      if(error){
        response.send("error in deletion");
      }

      else{
        response.send("successfully deleted");
      }

    });
  }
  catch(error){
    response.send("Deletion unsuccessful");
  }

}