

async function addAndNavigate() {
   var e= add1(); 
    
  
    
  document.getElementById("form1").style.display="none";
  document.getElementById("form2").style.display="block";
   //   setTimeout(()=>{window.location.href = "postproperty1.html" },5000)  

   try{
      const response=await  fetch("http://localhost:5501/postproperty", {
         method: 'POST',
         headers: {
             'Content-Type': 'application/json',
         },
         body: JSON.stringify(e),
     });
      const users= await response.json();
      console.log(users);
   }
   catch(error){
   console.log(error);
   }
    
}
function addAndNavigate2() {
    add2(); 
  
    document.getElementById("form2").style.display="none";
  document.getElementById("form3").style.display="block";
      //   window.location.href = "postproperty2.html"; 

}

function add1() {
   const rType=document.getElementById("room");
   const rTypeselect =  rType.options[rType.selectedIndex].value ;
   const pType=document.getElementById("property-type");
   const pTypeselect = pType.options[pType.selectedIndex].value;
   const condition=document.getElementById("condition");
   const conditionselect = condition.options[condition.selectedIndex].value;
   const noofrooms=document.getElementById("noofrooms").value;
   const noofbed=document.getElementById("noofbed").value;
   const noofbath=document.getElementById("noofbath").value;
   const rent=document.getElementById("rent").value;
   const area=document.getElementById("ucost").value;
   const date=document.getElementById("availdate").value;
   const month=document.getElementById("month").value;
   const mates=document.getElementById("mates");
   const matesselect = mates.options[mates.selectedIndex].value;
   const gender=document.getElementById("gender");
   const genderselect = gender.options[gender.selectedIndex].value;
   const occupation=document.getElementById("occupation");
   const occupationselect = occupation.options[occupation.selectedIndex].value;
   const amenties=document.getElementsByName("amenity");
   const samenties=[];
   amenties.forEach((amenity) => {
       if(amenity.checked)
       samenties.push(amenity.value); 
   });
         var newElement;
         if((typeof newElement)==="undefined"){
            newElement=[];
         }

      newElement.push({
            "roomType": rTypeselect,
            "propertyType": pTypeselect,
          "condition": conditionselect,
            "noOfRooms": noofrooms,
            "noOfBeds": noofbed,
            "noOfBaths": noofbath,
            "rent": rent,
            "area": area,
            "availabilityDate": date,
            "month": month,
            "mates": matesselect,
            "gender": genderselect,
            "occupation": occupationselect,
            "amenities": samenties
        });

        return newElement;
   
   

   }
 
 

 function add2() {
const ident=document.getElementById("identity");
const identselect=ident.options[ident.selectedIndex].value;
const city=document.getElementById("city").value;
const address=document.getElementById("address").value;
const landmark=document.getElementById("landmark").value;
const title=document.getElementById("title").value;
const describe=document.getElementById("describe").value;

var newElement1;
   if(localStorage.getItem("newElement1")==="undefined"){
      newElement1=[];
   }
   else{
      newElement1=JSON.parse(localStorage.getItem("newElement1"));
    }
newElement1.push({
    ident: identselect,
    city: city,
    address: address,
    landmark: landmark,
    title: title,
    describe: describe,
});
localStorage.setItem("newElement1",JSON.stringify(newElement1));

 }

 function add3(){
   const i=document.getElementById("img");
   const file=i.files[0];
   if(file){
   const reader = new FileReader();
   reader.onload = function(e) {
     const base64Image = e.target.result;

      }}   
       
}

 
function retrieve(){

    const newElementData = JSON.parse(localStorage.getItem('newElement'))??[]
  
         const newElementData1 =JSON.parse( localStorage.getItem('newElement1') )??[]
         const newElementData2 =JSON.parse(localStorage.getItem('newElement2'))??[]
         
         newElementData1.forEach((e,i)=>{
          
        if (e.title && e.describe) {
        const listingContainer = document.getElementById('listing-container');
        
        const adElement = document.createElement('div');
        adElement.className = 'col-md-4 mb-4';
       
        adElement.innerHTML = `
        
        <div class="card" style="width: 18rem; height: 420px; margin-left:40px;">
        <img class="card-img-top" src="" alt="Card image cap" width="350" height="300">
        <div class="card-body">
            <h5 class="card-title">${e.title}</h5>
            <p>${e.describe}<p>
            <p><p>
             <button id="delete" onclick="deletecard('${i}',this)">Delete
            </button>
             <button id="update" type="submit" onclick="update('${i}')">Update
            </button>
        </div>
        </div>
    
   `;
   listingContainer.appendChild(adElement);
   
 }
});
  
} 


function deletecard(index,btn)
     {
        const newElementData=JSON.parse(localStorage.getItem("newElement"))??[];
        const newElementData1=JSON.parse(localStorage.getItem("newElement1"))??[];
        const newElementData2=JSON.parse(localStorage.getItem("newElement2"))??[];
        newElementData.splice(index,1);
        newElementData1.splice(index,1);
        newElementData2.splice(index,1);
      
       
         const parent=btn.closest(".card");
         parent.remove();
        localStorage.setItem("newElement",JSON.stringify(newElementData));
        localStorage.setItem("newElement1",JSON.stringify(newElementData1));
        localStorage.setItem("newElement2",JSON.stringify(newElementData2));
        
       
    }

function update(i){


window.location.href="update.html";

const newElementData=JSON.parse(localStorage.getItem("newElement"))??[];
const newElementData1=JSON.parse(localStorage.getItem("newElement1"))??[];
console.error(newElementData[i]);
if(window.location.pathname="/update.html"){
   const rType=document.getElementById("room");
   rType.value=newElementData[i].roomType ;


}

}
function validate(){
   
        var name = document.getElementById("name").value;
        var nameregex=/^[a-zA-Z\s]+$/;
        var email = document.getElementById("email").value;
        var password = document.getElementById("password").value;
        var passwordRegex = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{4,8}$/
        var contact=document.getElementById("contact").value;
        var isValid = true;

        if(name.length === 0){
           document.getElementById("nameError").innerHTML = "Name is required";
           isValid=false;
        }
        else if(!nameregex.test(name)){
           document.getElementById("nameError").innerHTML = "Only letters needed";
           isValid=false;

        }
        if(email.length === 0){
           document.getElementById("emailError").innerHTML = "Email is required";
           isValid = false;
        }
        else{
           document.getElementById("emailError").innerHTML = "";
        }
        if(password.length === 0){
           document.getElementById("passwordError").innerHTML = "Password is required";
           isValid = false;
        }
        else if(!passwordRegex.test(password)){
           document.getElementById("passwordError").innerHTML = "Password must be at least 4 characters, no more than 8 characters, and must include at least one upper case letter, one lower case letter, and one numeric digit.";
           isValid = false;
        }
        if(contact.length === 0){
            document.getElementById("contactError").innerHTML = "Contact Number is required";
            isValid = false;
         }
         else if(contact.length >10 ||contact.length <10 ){
            document.getElementById("contactError").innerHTML = " Enter a valid number";
            isValid = false;
         }
         else{
            document.getElementById("contactError").innerHTML = "";
         }
         if(isValid){

            document.getElementById('message').innerText = 'Sign up successful!';
        }
        return isValid;
    }

   
    

    function validateC(){
        var name = document.getElementById("name").value;
        var email = document.getElementById("email").value;
        var subject = document.getElementById("c-sub").value;
        
        var msg=document.getElementById("c-msg").value;
        var isValid = true;

        if(name.length === 0){
           document.getElementById("nameError").innerHTML = "Name is required";
           isValid=false;
        }
        else{
           document.getElementById("nameError").innerHTML = "";
        }
        if(email.length === 0){
           document.getElementById("emailError").innerHTML = "Email is required";
           isValid = false;
        }
        else{
           document.getElementById("emailError").innerHTML = "";
        }
        if(subject.length === 0){
           document.getElementById("subError").innerHTML = "Subject is required";
           isValid = false;
        }
        else {
            document.getElementById("subError").innerHTML = "";
         
        }
        if(msg.length === 0){
            document.getElementById("msgError").innerHTML = "Message is required";
            isValid = false;
         }
         
         else{
            document.getElementById("msgError").innerHTML = "";
         }
        return isValid;
    }

    function validateIn(){
    
        var email = document.getElementById("email").value;
        var password = document.getElementById("password").value;
        var passwordRegex = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{4,8}$/
       
        var isValid = true;

       
        if(email.length === 0){
           document.getElementById("emailError").innerHTML = "Email is required";
           isValid = false;
        }
        else{
           document.getElementById("emailError").innerHTML = "";
        }
        if(password.length === 0){
           document.getElementById("passwordError").innerHTML = "Password is required";
           isValid = false;
        }
        else if(!passwordRegex.test(password)){
           document.getElementById("passwordError").innerHTML = "incorrect password";
           isValid = false;
        }
       

        return isValid;
         }

