import express from 'express';
import { establishConnection,connectionObj } from './config/dbConfig.js';
// import  propertyRouter  from './Router/PropertyRouter.js';  // don't use {} with default expo
import cors from 'cors';
const app=express();
const PORT=5502;

 // don't use {} with default expo

app.use(cors());
app.use(cors({ origin: "http://127.0.0.1:5501", credentials: true }));

app.use(express.json());


app.post("/postproperty",(request,response)=>{
  try{ 
    const data=request.body;
    console.log(request.body);
   const insertQuery=`INSERT INTO property(pType,rtpe,pcondition, availR, totalBed,totalBath,rent,area,uCost,minMonth,mates,genderPref,occupation,amenity,identity,city,address,landmark,title,description,id) VALUES (?, ?, ?, ?, ?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`;
   const values=[data.pType,data.rtype,data.pcondition,data.availR,data.totalBed,data.totalBath,data.rent,data.area,data.ucost,data.minMonth,data.mates,data.genderPref,data.occupation,data.amenties,data.identity,data.city,data.address,data.landmark,data.title,data.description,data.id];
       connectionObj().query(insertQuery,values,(error)=>{
     if(error){
      console.log(error);
       response.send("Unable to insert entry");
     }

     else{
       response.send("successfully inserted");
     }

   });
 }
 catch(error){
   response.send("error inserting1");
  }

});


app.get("/searchproperty",(request,response)=>{
  try{  
    
    const insertQuery=`select * from property`;
    connectionObj().query(insertQuery,(error,result)=>{
      if(error){
        response.send("error displaying");
      }

      else{
        response.json(result);
      }

    });
  }
  catch(error){
    response.send("Error displaying");
  }

});

app.delete("/searchproperty",(request,response)=>{
  try{  const {id}=request.body;
    const deleteQuery=`delete from property where id=?`;
    connectionObj().query(deleteQuery,[id],(error)=>{
      if(error){
        response.send("error in deletion");
      }

      else{
        response.send("successfully deleted");
      }

    });
  }
  catch(error){
    response.send("Deletion unsuccessful");
  }

})

app.put('/update', (request, response) => {
  
  const { pType,rtype,pcondition,availR,totalBed,totalBath,rent,area,ucost,minMonth,mates,genderPref,occupation,amenties,identity,city,address,landmark,title,description,id } = request.body;
  const query = 'UPDATE property SET pType=? ,rtpe=?,pcondition=?, availR=?, totalBed=?,totalBath=?,rent=?,area=?,uCost=?,minMonth=?,mates=?,genderPref=?,occupation=?,amenity=?,identity=?,city=?,address=?,landmark=?,title=?,description=? where id=?';
  connectionObj().query(query, [pType,rtype,pcondition,availR,totalBed,totalBath,rent,area,ucost,minMonth,mates,genderPref,occupation,amenties,identity,city,address,landmark,title,description,id], (error, result) => {
      if (error) {
          console.error('Error updating property:', error);
          response.status(500).send('Error updating property');
          return;
      }
      response.send('Property updated successfully.');
  });
});


app.get("/searchproperty",(request,response)=>{
  try{  
    const {id}=request.body;
    const insertQuery=`select * from property where id=${id}`;
    connectionObj().query(insertQuery,(error,result)=>{
      if(error){
        response.send("error displaying");
      }

      else{
        response.json(result);
      }

    });
  }
  catch(error){
    response.send("Error displaying");
  }

});
app.listen(PORT,()=>{
  console.log("server connected");
  establishConnection();
})