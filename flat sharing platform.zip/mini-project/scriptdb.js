var e1;
var e2;

function addAndNavigate() {
   
   e1= add1(); 
   console.log(e1);
   document.getElementById("form1").style.display="none";
   document.getElementById("form2").style.display="block";
    }

function postback(){

   document.getElementById("form2").style.display="none";
   document.getElementById("form1").style.display="block";
}
 
 function add1() {
   
    
    const rType=document.getElementById("room");
    const rTypeselect =  rType.options[rType.selectedIndex].value ;
    const pType=document.getElementById("property-type");
    const pTypeselect = pType.options[pType.selectedIndex].value;
    const condition=document.getElementById("condition");
    const conditionselect = condition.options[condition.selectedIndex].value;
    const noofrooms=document.getElementById("noofrooms").value;
    const noofbed=document.getElementById("noofbed").value;
    const noofbath=document.getElementById("noofbath").value;
    const rent=document.getElementById("rent").value;
    const area=document.getElementById("area").value;
    const ucost=document.getElementById("ucost").value;
    const date=document.getElementById("availdate").value;
    const month=document.getElementById("month").value;
    const mates=document.getElementById("mates");
    const matesselect = mates.options[mates.selectedIndex].value;
    const gender=document.getElementById("gender");
    const genderselect = gender.options[gender.selectedIndex].value;
    const occupation=document.getElementById("occupation");
    const occupationselect = occupation.options[occupation.selectedIndex].value;
    const amenties=document.getElementsByName("amenity");
    const samenties=[];
    amenties.forEach((amenity) => {
        if(amenity.checked)
        samenties.push(amenity.value); 
    });
      
    
    if(!validateForm1){
      alert("Please fill all the fields correctly");
    }  
    const newElement={
   
  rtype:rTypeselect,
  pType:pTypeselect,
  pcondition:conditionselect,
  availR:noofrooms,
  totalBed:noofbed,
  totalBath:noofbath,
  rent:rent,
  area:area,
  ucost:ucost,
  minMonth:month,
  mates:matesselect,
  genderPref:genderselect,
  occupation:occupationselect,
  amenity:samenties,
} 
    return newElement;
  }

  
 
  function add2() {
 const ident=document.getElementById("identity");
 const identselect=ident.options[ident.selectedIndex].value;
 const city=document.getElementById("city").value;
 const address=document.getElementById("address").value;
 const landmark=document.getElementById("landmark").value;
 const title=document.getElementById("title").value;
 const describe=document.getElementById("describe").value;
 
 if(validateForm2){
 const newElement1={
     identity: identselect,
     city: city,
     address: address,
     landmark: landmark,
     title: title,
     description: describe,
 };
 return newElement1;
 }
 
  }
 function fSubmit(){
    
   
     e2=add2();
     const e={...e1,...e2};
     const es=JSON.stringify(e);
     console.log(es);

var req=new XMLHttpRequest();
req.open("POST","http://127.0.0.1:5502/postproperty");
req.setRequestHeader("Content-type","application/json");

req.send(es);

req.onreadystatechange=function(){
    if(req.readyState===4 && req.status==200){
        alert(req.responseText);
    }
}
    return false;   
 }
 
  
 function retrieve(){
    
    var xhr=new XMLHttpRequest();
    xhr.open("GET","http://127.0.0.1:5502/searchproperty");
    
    
    xhr.onload=function(){
         
        if(xhr.status==200){
         const data=JSON.parse(xhr.responseText); 
        console.log(data);
        
         data.forEach((e,i)=>{
           
         if (e.title && e.description) {
         const listingContainer = document.getElementById('listing-container');
      
         const adElement = document.createElement('div');
         adElement.className = 'col-md-4 mb-4';
        
         adElement.innerHTML = `
         
         <div class="card" style="width: 18rem; height: 420px; margin-left:40px;">
         <img class="card-img-top" src="" alt="Card image cap" width="350" height="300">
         <div class="card-body">
             <h5 class="card-title">${e.title}</h5>
             <p>${e.description}<p>
             <p><p>
              <button id="delete" onclick="deletecard('${e.id}',this,)">Delete
             </button>
              <button id="update" type="submit" onclick="updateNext('${e.id}')">Update
             </button>
         </div>
         </div>
     
    `;
    listingContainer.appendChild(adElement);
    
  }
 });
 
}}
xhr.send();
 }
 
 
 function deletecard(index,btn)
      {
         
         var req=new XMLHttpRequest();
         req.open("DELETE", `http://127.0.0.1:5502/searchproperty`, true);
         req.setRequestHeader("Content-Type", "application/json");
         const i=JSON.stringify({id:index}); 
      
         req.send(i);
         req.onload=function(){
            if(req.status===200 && req.readyState===4){

               console.log("deleted");
               const parent=btn.closest(".card");
               parent.remove();
               alert(req.responseText);
            }
            else {
                console.error(`Failed to delete. Status: ${req.status}`);
              }
         }
       
     }
 
 function updateSave() {

 var req=new XMLHttpRequest();
 req.open("PUT", `http://127.0.0.1:5502/update`, true);
 req.setRequestHeader("Content-Type", "application/json");
 e2=add2();
 const id=JSON.parse(localStorage.getItem("index"))
 const e={...e1,...e2,id};
 console.log(e);
 const i=JSON.stringify(e); 

 req.send(i);

 req.onload=function(){
    if(req.status===200 && req.readyState===4){
      alert(req.responseText);
    }
    else {
        console.error(`failed to update`);
      }
 }
  
 }

 function updateNext(index){
   window.location.href="update.html";
   console.log(index);
   localStorage.setItem("index",JSON.stringify(index));
  
 }

async function update(){

   const index=JSON.parse(localStorage.getItem("index"));
   console.log(index);

   if(window.location.href="update.html"){
try{
      const data= await fetch('http://localhost:5502/searchproperty', {
      method: 'GET',
      headers: {
          'Content-Type': 'application/json'
      },
       body:JSON.stringify(index)
  })
  console.log(data);
  }
   
catch(error){
   console.log(error);
}}
return false;
   }


function validateForm1(){
    
   const rType=document.getElementById("room");
   const rTypeselect =  rType.options[rType.selectedIndex].value ;
   const pType=document.getElementById("property-type");
   const pTypeselect = pType.options[pType.selectedIndex].value;
   const condition=document.getElementById("condition");
   const conditionselect = condition.options[condition.selectedIndex].value;
   const noofrooms=document.getElementById("noofrooms").value;
   const noofbed=document.getElementById("noofbed").value;
   const noofbath=document.getElementById("noofbath").value;
   const rent=document.getElementById("rent").value;
   const area=document.getElementById("area").value;
   const ucost=document.getElementById("ucost").value;
   const date=document.getElementById("availdate").value;
   const currentDate = new Date();
   const month=document.getElementById("month").value;
   const mates=document.getElementById("mates");
   const matesselect = mates.options[mates.selectedIndex].value;
   const gender=document.getElementById("gender");
   const genderselect = gender.options[gender.selectedIndex].value;
   const occupation=document.getElementById("occupation");
   const occupationselect = occupation.options[occupation.selectedIndex].value;
    var isValid=true;
      if(rTypeselect==="Choose"){
         isValid=false;
      }
      if(pTypeselect==="Choose"){
        
         isValid = false;
      }
      if(conditionselect === "Choose"){
         isValid = false;
      }
      if(noofrooms===""){
          isValid = false;
       }
       if(noofbed===""){
         isValid = false;
      }
      if(noofbath===""){
         isValid = false;
      }
      if(rent===""){
         isValid = false;
      }
      if(area===""){
         isValid = false;
      }
      if(ucost===""){
         isValid = false;
      }

      if(date<currentDate)
      { isValid=false;

      }
      if(month==="" || month>12 || month<1)
      { isValid=false;

      }
      if(matesselect==="Choose")
      { isValid=false;

      }
      if(genderselect==="Choose")
         { isValid=false;
   
         }
      if(occupationselect==="Choose")
         { isValid=false;
   
         }
       if(!isValid)
         alert("Please fill all the fields correctly");
         
      return isValid;
}

function validateForm2(){
    
   const ident=document.getElementById("identity");
 const identselect=ident.options[ident.selectedIndex].value;
 const city=document.getElementById("city").value;
 const address=document.getElementById("address").value;
 const landmark=document.getElementById("landmark").value;
 const title=document.getElementById("title").value;
 const describe=document.getElementById("describe").value;
   var isValid = true;

   if(identselect=== "Choose"){
      
      isValid=false;
   }
   
   if(city.length === 0){
    
      isValid = false;
   }
   if(address.length === 0){
      
      isValid = false;
   }
 
   if(landmark.length === 0){
       
       isValid = false;
    }
    if(title.length === 0){
       
      isValid = false;
   }
   if(describe.length === 0){
       
      isValid = false;
   }

    if(!isValid){
alert("Fill all the fields correctly");
       
   }
   return isValid;
}


 function validate(){
    
         var name = document.getElementById("name").value;
         var nameregex=/^[a-zA-Z\s]+$/;
         var email = document.getElementById("email").value;
         var password = document.getElementById("password").value;
         var passwordRegex = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{4,8}$/
         var contact=document.getElementById("contact").value;
         var isValid = true;
 
         if(name.length === 0){
            document.getElementById("nameError").innerHTML = "Name is required";
            isValid=false;
         }
         else if(!nameregex.test(name)){
            document.getElementById("nameError").innerHTML = "Only letters needed";
            isValid=false;
 
         }
         if(email.length === 0){
            document.getElementById("emailError").innerHTML = "Email is required";
            isValid = false;
         }
         else{
            document.getElementById("emailError").innerHTML = "";
         }
         if(password.length === 0){
            document.getElementById("passwordError").innerHTML = "Password is required";
            isValid = false;
         }
         else if(!passwordRegex.test(password)){
            document.getElementById("passwordError").innerHTML = "Password must be at least 4 characters, no more than 8 characters, and must include at least one upper case letter, one lower case letter, and one numeric digit.";
            isValid = false;
         }
         if(contact.length === 0){
             document.getElementById("contactError").innerHTML = "Contact Number is required";
             isValid = false;
          }
          else if(contact.length >10 ||contact.length <10 ){
             document.getElementById("contactError").innerHTML = " Enter a valid number";
             isValid = false;
          }
          else{
             document.getElementById("contactError").innerHTML = "";
          }
          if(isValid){
 
             document.getElementById('message').innerText = 'Sign up successful!';
         }
         return isValid;
     }
 
    
     
 
     function validateC(){
         var name = document.getElementById("name").value;
         var email = document.getElementById("email").value;
         var subject = document.getElementById("c-sub").value;
         
         var msg=document.getElementById("c-msg").value;
         var isValid = true;
 
         if(name.length === 0){
            document.getElementById("nameError").innerHTML = "Name is required";
            isValid=false;
         }
         else{
            document.getElementById("nameError").innerHTML = "";
         }
         if(email.length === 0){
            document.getElementById("emailError").innerHTML = "Email is required";
            isValid = false;
         }
         else{
            document.getElementById("emailError").innerHTML = "";
         }
         if(subject.length === 0){
            document.getElementById("subError").innerHTML = "Subject is required";
            isValid = false;
         }
         else {
             document.getElementById("subError").innerHTML = "";
          
         }
         if(msg.length === 0){
             document.getElementById("msgError").innerHTML = "Message is required";
             isValid = false;
          }
          
          else{
             document.getElementById("msgError").innerHTML = "";
          }
         return isValid;
     }
 
     function validateIn(){
     
         var email = document.getElementById("email").value;
         var password = document.getElementById("password").value;
         var passwordRegex = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{4,8}$/
        
         var isValid = true;
 
        
         if(email.length === 0){
            document.getElementById("emailError").innerHTML = "Email is required";
            isValid = false;
         }
         else{
            document.getElementById("emailError").innerHTML = "";
         }
         if(password.length === 0){
            document.getElementById("passwordError").innerHTML = "Password is required";
            isValid = false;
         }
         else if(!passwordRegex.test(password)){
            document.getElementById("passwordError").innerHTML = "incorrect password";
            isValid = false;
         }
        
 
         return isValid;
          }