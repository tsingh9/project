import { createConnection } from "mysql";

export function connectionObj(){
    return createConnection({
                    host:"localhost",
                    user:"root",
                    password:"root",
                    database:"test"
                    });

}

export function establishConnection(){
        connectionObj().connect((error)=>{
        if(error){
            console.log(error);
            console.log("connection not established");
            }
        else{
            console.log("connection established");
        }
        })


}