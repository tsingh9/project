import {Router} from 'express';
import { AddPropertyController } from '../Controller/PropertyController.js';
import { DisplayPropertyController } from '../Controller/PropertyController.js';
import { DeletePropertyController} from '../Controller/PropertyController.js';

const propertyRouter=Router();

propertyRouter.delete('/:id',DeletePropertyController);

propertyRouter.post('/postproperty',AddPropertyController);
propertyRouter.post('/searchproperty',DisplayPropertyController);

export default propertyRouter;